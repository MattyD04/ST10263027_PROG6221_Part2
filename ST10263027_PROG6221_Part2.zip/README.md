# RecipeManagerPOE
1) Make sure you have Microsoft Visual Stuidos installed with the necessary files (such as the .NET SDK) installed.
2) Unzip the file and open Visual Studios
3) Navigate to File then Open Project Solution and select the project
4) Once it has opened, go to the top of the screen and navigate to Build and selecct "Build Solution"
5) Once that is successful. go to the top where you see the green triangle with the word "Start" next to it and click that.
6) The application should now run successfully!
